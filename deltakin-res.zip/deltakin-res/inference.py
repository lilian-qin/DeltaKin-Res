"""Evaluate a GAT-GCN checkpoint on the fixed test split."""

import argparse
import torch
from torch.utils.data import Subset
import pandas as pd
from pathlib import Path
from models.gat_gcn_pair import GAT_GCN
from models.esm_pair import difference_v2_architecture_from_state_dict
from models.shared_difference_v1 import GAT_GCN as DifferenceV1GAT_GCN
from scripts.split import load_split
from utils import *


def predicting(model, device, loader):
    model.eval()
    total_preds = torch.Tensor()
    total_labels = torch.Tensor()
    all_compound_ids = []
    all_kinase_A_ids = []
    all_kinase_B_ids = []
    all_source_rows = []
    print('Make prediction for {} samples...'.format(len(loader.dataset)))
    with torch.no_grad():
        for data in loader:
            data = data.to(
                device, non_blocking=(PIN_MEMORY and device.type == 'cuda')
            )
            output = model(data)
            total_preds = torch.cat((total_preds, output.cpu()), 0)
            total_labels = torch.cat((total_labels, data.y.view(-1, 1).cpu()), 0)
            all_compound_ids.extend(data.compound_id if isinstance(data.compound_id, list)
                                    else data.compound_id.cpu().tolist())
            all_kinase_A_ids.extend(data.kinase_A_id)
            all_kinase_B_ids.extend(data.kinase_B_id)
            all_source_rows.extend(data.source_row.cpu().tolist())
    return (total_labels.numpy().flatten(),
            total_preds.numpy().flatten(),
            all_compound_ids,
            all_kinase_A_ids,
            all_kinase_B_ids,
            all_source_rows)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('model_path', type=Path)
parser.add_argument('--pair-head', choices=('difference_v1', 'difference_v2'),
                    default='difference_v2')
parser.add_argument('--cuda-id', type=int, default=0)
parser.add_argument('--esm-cache', default='data/wt_esm/esm2_t33_650M_UR50D_residue.pt')
parser.add_argument('--data-root', default='data/wt_esm')
parser.add_argument('--split', type=Path, default=Path('data/wt_esm/split.npz'))
parser.add_argument('--output', type=Path)
args = parser.parse_args()

pair_head = args.pair_head
modeling = GAT_GCN if pair_head == 'difference_v2' else DifferenceV1GAT_GCN
model_st = modeling.__name__
cuda_name = f'cuda:{args.cuda_id}'

print(f'Model: {model_st}, Pair head: {pair_head}')
print(f'Loading weights: {args.model_path}')
print(f'Device: {cuda_name}')

# ---- Load data ----
TEST_BATCH_SIZE = 256
NUM_WORKERS = 4
device = torch.device(cuda_name if torch.cuda.is_available() else "cpu")
PIN_MEMORY = device.type == 'cuda'

esm_transform = ESMEmbeddingTransform(
    args.esm_cache, require_residue=(pair_head == 'difference_v2')
)
full_data = SiameseTestbedDataset(root=args.data_root, dataset='selectivity_all_wt', transform=esm_transform)
parts = load_split(full_data, args.split)
test_data = Subset(full_data, parts['test'].tolist())
test_loader = make_pair_data_loader(
    test_data, batch_size=TEST_BATCH_SIZE, esm_transform=esm_transform,
    shuffle=False, num_workers=NUM_WORKERS, pin_memory=PIN_MEMORY,
)

# ---- Load model ----
state_dict = torch.load(args.model_path, weights_only=False, map_location=device)
model_kwargs = (
    difference_v2_architecture_from_state_dict(state_dict)
    if pair_head == 'difference_v2' else {}
)
model = modeling(
    pool_method='esm', esm_dim=esm_transform.dim, **model_kwargs
).to(device)
model.load_state_dict(state_dict)
if model_kwargs:
    print(f'Residue branch: {model_kwargs}')
print(f'Model loaded successfully')

# ---- Predict ----
G_test, P_test, compound_ids, kinase_A_ids, kinase_B_ids, source_rows = predicting(model, device, test_loader)

# ---- Metrics ----
test_ret = [rmse(G_test, P_test), mse(G_test, P_test),
            pearson(G_test, P_test), spearman(G_test, P_test)]

print(f'\n===== Test Results ({model_st} + esm) =====')
print(f'RMSE:     {test_ret[0]:.4f}')
print(f'MSE:      {test_ret[1]:.4f}')
print(f'Pearson:  {test_ret[2]:.4f}')
print(f'Spearman: {test_ret[3]:.4f}')

# ---- Save per-sample predictions ----
pred_file_name = args.output or Path(f'pred_{args.model_path.stem}.csv')
pred_df = pd.DataFrame({
    'ligand_key': compound_ids,
    'kinase_A': kinase_A_ids,
    'kinase_B': kinase_B_ids,
    'source_row': source_rows,
    'pred_score': P_test,
    'true_label': G_test,
})

pred_df.to_csv(pred_file_name, index=False)
print(f'Predictions saved to {pred_file_name} ({len(pred_df)} samples)')
