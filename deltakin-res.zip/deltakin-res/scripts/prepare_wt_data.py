"""Build one unsplit ligand graph dataset from data/pairs_final_wt.csv.

Each sample retains its SMILES, source CSV row, ligand key, label, and kinase
IDs so different train/validation/test splits can be applied later.
Protein features come from the ESM cache at dataset read time.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from rdkit import Chem

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from utils import SiameseTestbedDataset


ATOM_SYMBOLS = ['C', 'N', 'O', 'S', 'F', 'Si', 'P', 'Cl', 'Br', 'Mg', 'Na',
                'Ca', 'Fe', 'As', 'Al', 'I', 'B', 'V', 'K', 'Tl', 'Yb',
                'Sb', 'Sn', 'Ag', 'Pd', 'Co', 'Se', 'Ti', 'Zn', 'H',
                'Li', 'Ge', 'Cu', 'Au', 'Ni', 'Cd', 'In', 'Mn', 'Zr',
                'Cr', 'Pt', 'Hg', 'Pb', 'Unknown']
COUNTS = list(range(11))


def one_hot(value, options, unknown=False):
    if value not in options:
        if not unknown:
            raise ValueError(f'Unsupported atom property: {value}')
        value = options[-1]
    return [value == option for option in options]


def smile_to_graph(smile):
    mol = Chem.MolFromSmiles(smile)
    if mol is None:
        return None
    features = []
    for atom in mol.GetAtoms():
        feature = np.asarray(
            one_hot(atom.GetSymbol(), ATOM_SYMBOLS, unknown=True)
            + one_hot(atom.GetDegree(), COUNTS)
            + one_hot(atom.GetTotalNumHs(), COUNTS, unknown=True)
            + one_hot(atom.GetValence(Chem.ValenceType.IMPLICIT), COUNTS, unknown=True)
            + [atom.GetIsAromatic()], dtype=np.float32)
        features.append(feature / feature.sum())
    edges = []
    for bond in mol.GetBonds():
        a, b = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        edges.extend(((a, b), (b, a)))
    return mol.GetNumAtoms(), features, edges


def prepare_dataset(pairs_path, root):
    name = 'selectivity_all_wt'
    output = root / 'processed' / f'{name}.pt'
    if output.exists():
        if output.stat().st_mtime < pairs_path.stat().st_mtime:
            raise FileExistsError(f'{output} predates {pairs_path}; choose a new --root for refreshed data')
        print(f'{output} exists; leaving it unchanged')
        return
    columns = ['ligand_key', 'std_smiles', 'uniprot_A', 'uniprot_B',
               'domain_seq_A', 'domain_seq_B', 'delta_pIC50_median']
    df = pd.read_csv(pairs_path, usecols=columns)
    if df[['std_smiles', 'uniprot_A', 'uniprot_B', 'domain_seq_A',
           'domain_seq_B', 'delta_pIC50_median']].isna().any().any():
        raise ValueError('Required SMILES, kinase, sequence or label is missing')
    if not np.isfinite(df['delta_pIC50_median'].to_numpy(dtype=float)).all():
        raise ValueError('Non-finite selectivity label in input CSV')

    df['ligand_key'] = df['ligand_key'].fillna(df['std_smiles'])
    graphs = {}
    for smiles in df['std_smiles'].unique():
        graph = smile_to_graph(smiles)
        if graph is not None:
            graphs[smiles] = graph
    print(f'Constructed {len(graphs)} of {df.std_smiles.nunique()} ligand graphs', flush=True)
    df = df[df['std_smiles'].isin(graphs)]
    if df.empty:
        raise ValueError('No valid SMILES in the input CSV')
    print(f'Packaging {len(df)} rows into {output}', flush=True)
    SiameseTestbedDataset(
        root=str(root), dataset=name, xd=df['std_smiles'].to_numpy(),
        y=df['delta_pIC50_median'].to_numpy(), smile_graph=graphs,
        compound_ids=df['ligand_key'].to_numpy(),
        kinase_A_ids=df['uniprot_A'].to_numpy(),
        kinase_B_ids=df['uniprot_B'].to_numpy(),
        smiles_strings=df['std_smiles'].to_numpy(), source_rows=df.index.to_numpy(),
    )
    print(f'Finished graph preprocessing: {output}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pairs', type=Path, default=Path('data/pairs_final_wt.csv'))
    parser.add_argument('--root', type=Path, default=Path('data/wt_esm'))
    args = parser.parse_args()
    prepare_dataset(args.pairs, args.root)


if __name__ == '__main__':
    main()
