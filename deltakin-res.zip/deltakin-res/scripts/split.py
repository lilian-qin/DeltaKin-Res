"""Load the fixed ligand-disjoint train/validation/test split."""

import hashlib

import numpy as np


def dataset_fingerprint(dataset):
    data = dataset._data
    if not hasattr(data, 'smiles') or not hasattr(data, 'source_row'):
        raise ValueError('Processed dataset lacks smiles/source_row metadata')
    if len(data.smiles) != len(dataset) or len(data.source_row) != len(dataset):
        raise ValueError('Processed dataset metadata length mismatch')
    digest = hashlib.sha256()
    for smile, source_row in zip(data.smiles, data.source_row):
        digest.update(f'{int(source_row)}:{len(smile)}:{smile}\n'.encode('utf-8'))
    return digest.hexdigest()


def load_split(dataset, path):
    with np.load(path, allow_pickle=False) as saved:
        expected = {'train', 'val', 'test', 'dataset_size', 'dataset_sha256'}
        if set(saved.files) != expected:
            raise ValueError(f'{path} has unexpected or missing fields')
        if int(saved['dataset_size']) != len(dataset):
            raise ValueError(f'{path} was generated for a different dataset size')
        if str(saved['dataset_sha256']) != dataset_fingerprint(dataset):
            raise ValueError(f'{path} does not match the processed dataset')
        parts = {name: saved[name] for name in ('train', 'val', 'test')}

    for name, indices in parts.items():
        if indices.ndim != 1 or indices.dtype.kind not in 'iu' or not len(indices):
            raise ValueError(f'{path}: {name} must be a nonempty integer array')
        if (indices < 0).any() or (indices >= len(dataset)).any():
            raise ValueError(f'{path}: {name} contains out-of-range indices')
    combined = np.concatenate(list(parts.values()))
    if len(combined) != len(dataset) or len(np.unique(combined)) != len(dataset):
        raise ValueError(f'{path}: train/val/test must partition the dataset')
    smiles = dataset._data.smiles
    ligand_sets = {
        name: {smiles[int(index)] for index in indices}
        for name, indices in parts.items()
    }
    if (ligand_sets['train'] & ligand_sets['val']
            or ligand_sets['train'] & ligand_sets['test']
            or ligand_sets['val'] & ligand_sets['test']):
        raise ValueError(f'{path}: ligand appears in multiple partitions')
    return parts
