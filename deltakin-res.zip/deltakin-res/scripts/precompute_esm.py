"""Compute frozen global and residue-level ESM2 kinase representations.

Usage: python scripts/precompute_esm.py [--device cpu] [--batch-size 4]
The default model is ESM2 t33 650M (1280 dimensions). Supply --model-path
to use a local copy of its checkpoint instead of the torch hub cache.
"""

import argparse
import csv
from pathlib import Path

import torch


MODEL_NAME = 'esm2_t33_650M_UR50D'


def read_kinases(pairs_path):
    kinases = {}
    with pairs_path.open(newline='') as handle:
        for row in csv.DictReader(handle):
            for suffix in ('A', 'B'):
                kinase, sequence = row[f'uniprot_{suffix}'], row[f'domain_seq_{suffix}']
                if not kinase or not sequence:
                    raise ValueError(f'Missing UniProt ID or domain sequence in {pairs_path}')
                if kinase in kinases and kinases[kinase] != sequence:
                    raise ValueError(f'Conflicting sequences for kinase {kinase}')
                kinases[kinase] = sequence
    return kinases


def compute_embeddings(kinases, model, alphabet, device, batch_size,
                       return_residue_embeddings=False,
                       residue_dtype=torch.float16):
    converter = alphabet.get_batch_converter()
    layer = model.num_layers
    embeddings = {}
    residue_embeddings = {}
    items = sorted(kinases.items(), key=lambda pair: len(pair[1]))
    model.eval().to(device)
    with torch.inference_mode():
        for start in range(0, len(items), batch_size):
            group = items[start:start + batch_size]
            _, _, tokens = converter(group)
            representations = model(tokens.to(device), repr_layers=[layer],
                                    return_contacts=False)['representations'][layer]
            for index, (kinase, sequence) in enumerate(group):
                # Skip the BOS/EOS and padding tokens; preserve the entire sequence.
                residues = representations[index, 1:len(sequence) + 1]
                embeddings[kinase] = residues.mean(0).float().cpu()
                if return_residue_embeddings:
                    residue_embeddings[kinase] = residues.to(
                        dtype=residue_dtype, device='cpu'
                    )
            print(f'ESM: {min(start + batch_size, len(items))}/{len(items)}', flush=True)
    if return_residue_embeddings:
        return embeddings, residue_embeddings
    return embeddings


def reusable_embeddings(cache, kinases, require_residue):
    """Retain only matching cached kinases; never reuse a mismatched sequence."""
    if cache.get('model') != MODEL_NAME or cache.get('dim') != 1280:
        raise ValueError('Base cache must contain ESM2 t33 650M embeddings')
    sequences = cache.get('sequences', {})
    global_embeddings = cache.get('embeddings', {})
    residue_embeddings = cache.get('residue_embeddings', {})
    if require_residue and not residue_embeddings:
        raise ValueError('Base cache must contain residue embeddings')
    reused = {}
    reused_residue = {}
    for kinase, sequence in kinases.items():
        if kinase not in global_embeddings:
            continue
        if sequences.get(kinase) != sequence:
            raise ValueError(f'Base ESM cache sequence differs for {kinase}')
        if require_residue and kinase not in residue_embeddings:
            raise ValueError(f'Base cache lacks residue embeddings for {kinase}')
        reused[kinase] = global_embeddings[kinase]
        if require_residue:
            reused_residue[kinase] = residue_embeddings[kinase]
    return reused, reused_residue


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pairs', type=Path, default=Path('data/pairs_final_wt.csv'))
    parser.add_argument('--output', type=Path,
                        default=Path('data/wt_esm/esm2_t33_650M_UR50D_residue.pt'))
    parser.add_argument('--model-path', type=Path, help='Local ESM2 t33 650M checkpoint')
    parser.add_argument(
        '--base-cache', type=Path,
        help='Reuse matching ESM embeddings; encode only new kinase sequences',
    )
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--batch-size', type=int, default=4)
    parser.add_argument(
        '--global-only', action='store_true',
        help='Write a smaller cache for difference_v1 only',
    )
    parser.add_argument(
        '--residue-dtype', choices=('float16', 'float32'), default='float16',
        help='On-disk dtype for residue embeddings (converted to float32 when loaded)',
    )
    args = parser.parse_args()
    if args.batch_size < 1:
        parser.error('--batch-size must be positive')
    if args.output.exists():
        parser.error(f'{args.output} already exists; select a different output path')
    kinases = read_kinases(args.pairs)
    embeddings = {}
    residue_embeddings = {}
    if args.base_cache is not None:
        base = torch.load(args.base_cache, map_location='cpu', weights_only=False)
        embeddings, residue_embeddings = reusable_embeddings(
            base, kinases, require_residue=not args.global_only
        )
        print(f'Reusing {len(embeddings)} kinases from {args.base_cache}', flush=True)
    missing = {kinase: sequence for kinase, sequence in kinases.items()
               if kinase not in embeddings}
    dim = 1280
    if missing:
        if args.model_path is None:
            args.model_path = Path(torch.hub.get_dir()) / 'checkpoints' / f'{MODEL_NAME}.pt'
        if not args.model_path.is_file():
            parser.error(f'Missing {args.model_path}; download the ESM2 checkpoint or use --model-path')
        regression_path = args.model_path.with_name(
            args.model_path.stem + '-contact-regression.pt'
        )
        if not regression_path.is_file():
            parser.error(f'Missing {regression_path}; fair-esm requires contact regression weights')
        import esm
        print(f'Encoding {len(missing)} of {len(kinases)} unique kinases '
              f'from {args.pairs}', flush=True)
        # Official ESM checkpoints store their training arguments as an
        # argparse.Namespace. PyTorch 2.6+ requires that type to be explicitly
        # allowlisted when fair-esm calls torch.load with weights_only=True.
        safe_globals = getattr(torch.serialization, 'safe_globals', None)
        if safe_globals is None:
            model, alphabet = esm.pretrained.load_model_and_alphabet_local(
                str(args.model_path)
            )
        else:
            with safe_globals([argparse.Namespace]):
                model, alphabet = esm.pretrained.load_model_and_alphabet_local(
                    str(args.model_path)
                )
        dim = model.embed_dim
        result = compute_embeddings(
            missing, model, alphabet, args.device, args.batch_size,
            return_residue_embeddings=not args.global_only,
            residue_dtype=getattr(torch, args.residue_dtype),
        )
        if args.global_only:
            embeddings.update(result)
        else:
            new_globals, new_residues = result
            embeddings.update(new_globals)
            residue_embeddings.update(new_residues)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cache = {
        'model': MODEL_NAME,
        'dim': dim,
        'source': str(args.pairs),
        'sequences': kinases,
        'embeddings': embeddings,
    }
    if not args.global_only:
        residue_embeddings = {
            kinase: residue.to(dtype=getattr(torch, args.residue_dtype))
            for kinase, residue in residue_embeddings.items()
        }
        cache['residue_embeddings'] = residue_embeddings
        cache['residue_dtype'] = args.residue_dtype
    torch.save(cache, args.output)
    print(f'Saved {args.output}')


if __name__ == '__main__':
    main()
