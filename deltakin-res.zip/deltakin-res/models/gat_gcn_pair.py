import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, GATConv
from torch_geometric.nn import global_mean_pool as gap, global_max_pool as gmp
from models.esm_pair import ESMSharedDifferenceHead


class GAT_GCN(torch.nn.Module):
    def __init__(self, n_output=1, num_features_xd=78, num_features_xt=25,
                 n_filters=32, embed_dim=128, output_dim=128, max_seq_len=108,dropout=0.2,
                 pool_method='esm', esm_dim=1280, residue_dim=256,
                 attn_hidden=256, local_hidden=256, residue_top_k=None):

        super(GAT_GCN, self).__init__()

        self.n_output = n_output
        if pool_method != 'esm':
            raise ValueError("Only pool_method='esm' is supported; use ESM embeddings")
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)

        # ===== Ligand GAT + GCN layers =====
        self.conv1 = GATConv(num_features_xd, num_features_xd, heads=10)
        self.conv2 = GCNConv(num_features_xd * 10, num_features_xd * 10)
        self.fc_g1 = torch.nn.Linear(num_features_xd * 10 * 2, 1500)
        self.fc_g2 = torch.nn.Linear(1500, output_dim)

        self.prediction_head = ESMSharedDifferenceHead(
            ligand_dim=output_dim, esm_dim=esm_dim, residue_dim=residue_dim,
            attn_hidden=attn_hidden, local_hidden=local_hidden,
            dropout=dropout, residue_top_k=residue_top_k,
        )

    def encode_ligand(self, x, edge_index, batch):
        """Encode ligand graph through GAT + GCN layers. Called once."""
        x = self.relu(self.conv1(x, edge_index))
        x = self.relu(self.conv2(x, edge_index))
        x = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)
        x = self.relu(self.fc_g1(x))
        x = self.dropout(x)
        x = self.fc_g2(x)
        return x

    def forward(self, data, return_aux=False):
        x_lig = self.encode_ligand(data.x, data.edge_index, data.batch)
        return self.prediction_head.forward_batch(x_lig, data, return_aux=return_aux)
