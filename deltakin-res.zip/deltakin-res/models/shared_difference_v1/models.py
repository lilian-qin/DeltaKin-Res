import torch
import torch.nn as nn
from torch_geometric.nn import GATConv, GCNConv
from torch_geometric.nn import global_max_pool as gmp
from torch_geometric.nn import global_mean_pool as gap

from .esm_pair import ESMPairDifferenceHead


class GAT_GCN(torch.nn.Module):
    def __init__(self, n_output=1, num_features_xd=78, num_features_xt=25,
                 n_filters=32, embed_dim=128, output_dim=128, max_seq_len=108,
                 dropout=0.2, pool_method='esm', esm_dim=1280):
        super().__init__()
        if pool_method != 'esm':
            raise ValueError("Only pool_method='esm' is supported; use ESM embeddings")
        self.n_output = n_output
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.conv1 = GATConv(num_features_xd, num_features_xd, heads=10)
        self.conv2 = GCNConv(num_features_xd * 10, num_features_xd * 10)
        self.fc_g1 = nn.Linear(num_features_xd * 10 * 2, 1500)
        self.fc_g2 = nn.Linear(1500, output_dim)
        self.prediction_head = ESMPairDifferenceHead(
            output_dim, esm_dim, 512, n_output, dropout
        )

    def encode_ligand(self, x, edge_index, batch):
        x = self.relu(self.conv1(x, edge_index))
        x = self.relu(self.conv2(x, edge_index))
        x = torch.cat([gmp(x, batch), gap(x, batch)], dim=1)
        x = self.relu(self.fc_g1(x))
        x = self.dropout(x)
        return self.fc_g2(x)

    def forward(self, data):
        ligand = self.encode_ligand(data.x, data.edge_index, data.batch)
        return self.prediction_head(ligand, data.esm_A, data.esm_B)
