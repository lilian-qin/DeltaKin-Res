"""Global-ESM shared-scorer models used as the difference-v1 baseline."""

from .models import GAT_GCN

__all__ = ['GAT_GCN']
