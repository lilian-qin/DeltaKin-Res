import torch
from torch import nn


class SharedLigandKinaseScorer(nn.Module):
    """Score one ligand/global-kinase pair with weights shared across A and B."""

    def __init__(self, ligand_dim=128, esm_dim=1280, hidden_dim=512,
                 n_output=1, dropout=0.2):
        super().__init__()
        self.ligand_dim = ligand_dim
        self.esm_dim = esm_dim
        self.net = nn.Sequential(
            nn.Linear(ligand_dim + esm_dim, 1024),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(1024, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, n_output),
        )

    def forward(self, ligand, kinase_global):
        if ligand.ndim != 2 or ligand.size(1) != self.ligand_dim:
            raise ValueError(
                f'Expected ligand embeddings with shape [batch, {self.ligand_dim}]'
            )
        if (kinase_global.ndim != 2
                or kinase_global.size(1) != self.esm_dim):
            raise ValueError(
                f'Expected ESM embeddings with shape [batch, {self.esm_dim}]'
            )
        if ligand.size(0) != kinase_global.size(0):
            raise ValueError('Ligand and protein batch sizes differ')
        return self.net(torch.cat((ligand, kinase_global), dim=1))


class ESMPairDifferenceHead(nn.Module):
    """Antisymmetric V1 head: score(ligand, A) - score(ligand, B)."""

    def __init__(self, ligand_dim=128, esm_dim=1280, hidden_dim=512,
                 n_output=1, dropout=0.2):
        super().__init__()
        self.esm_dim = esm_dim
        self.scorer = SharedLigandKinaseScorer(
            ligand_dim=ligand_dim,
            esm_dim=esm_dim,
            hidden_dim=hidden_dim,
            n_output=n_output,
            dropout=dropout,
        )

    def forward(self, ligand, esm_a, esm_b):
        if (esm_a.ndim != 2 or esm_b.shape != esm_a.shape
                or esm_a.size(1) != self.esm_dim):
            raise ValueError(
                f'Expected paired ESM embeddings with shape [batch, {self.esm_dim}]'
            )
        return self.scorer(ligand, esm_a) - self.scorer(ligand, esm_b)
