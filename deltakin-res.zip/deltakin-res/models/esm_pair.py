import torch
from torch import nn
from torch.nn import functional as F
from torch_geometric.utils import to_dense_batch

from models.residue_difference_v1.esm_pair import AntisymmetricResidueDiffBranch


def difference_v2_architecture_from_state_dict(state_dict):
    """Infer configurable V2 dimensions from a model state dict."""
    keys = {
        'residue_dim': 'prediction_head.residue_diff.residue_proj.0.weight',
        'attn_hidden': 'prediction_head.residue_diff.attn.0.weight',
        'local_hidden': 'prediction_head.residue_diff.local_scorer.0.weight',
    }
    missing = [key for key in keys.values() if key not in state_dict]
    if missing:
        raise ValueError(
            f'Checkpoint is missing difference_v2 parameters: {missing}'
        )
    architecture = {
        name: int(state_dict[key].shape[0]) for name, key in keys.items()
    }
    top_k_key = 'prediction_head.residue_diff._top_k_value'
    if top_k_key in state_dict:
        raise ValueError(
            'Checkpoint uses the archived shared residue-level scorer, not '
            'the active residue-difference branch'
        )
    return architecture


def load_pretrained_v1(model, state_dict):
    """Load a complete difference-v1 model into the frozen V1 part of V2."""
    if any(key.startswith('prediction_head.residue_diff.') for key in state_dict):
        raise ValueError('Expected a difference_v1 checkpoint, got difference_v2 weights')
    if any(key.startswith('prediction_head.shared_scorer.') for key in state_dict):
        raise ValueError('Expected a difference_v1 checkpoint, got difference_v2 weights')

    target_state = model.state_dict()
    transferred = {}
    source_keys = set()
    for target_key, target_value in target_state.items():
        if (target_key.startswith('prediction_head.residue_diff.')
                or target_key == 'prediction_head.local_scale'):
            continue
        source_key = target_key.replace(
            'prediction_head.shared_scorer.', 'prediction_head.scorer.', 1
        )
        if source_key not in state_dict:
            raise ValueError(
                f'V1 checkpoint is missing required parameter {source_key!r}'
            )
        source_value = state_dict[source_key]
        if source_value.shape != target_value.shape:
            raise ValueError(
                f'V1 parameter shape mismatch for {source_key!r}: '
                f'checkpoint {tuple(source_value.shape)}, model {tuple(target_value.shape)}'
            )
        transferred[target_key] = source_value
        source_keys.add(source_key)

    # The V1 scalar bias cancels exactly in score(L, A) - score(L, B).
    allowed_unused = {'prediction_head.scorer.net.6.bias'}
    unexpected = set(state_dict) - source_keys - allowed_unused
    if unexpected:
        raise ValueError(
            f'V1 checkpoint has unexpected parameters: {sorted(unexpected)}'
        )

    incompatible = model.load_state_dict(transferred, strict=False)
    expected_missing = {
        key for key in target_state
        if (key.startswith('prediction_head.residue_diff.')
            or key == 'prediction_head.local_scale')
    }
    if set(incompatible.missing_keys) != expected_missing:
        raise RuntimeError(
            f'Unexpected missing parameters while loading V1: '
            f'{incompatible.missing_keys}'
        )
    if incompatible.unexpected_keys:
        raise RuntimeError(
            f'Unexpected parameters while loading V1: {incompatible.unexpected_keys}'
        )
    return sorted(source_keys)


def freeze_pretrained_v1(model):
    """Freeze the ligand encoder and shared scorer, leaving only residue V2 trainable."""
    for parameter in model.parameters():
        parameter.requires_grad = False
    for parameter in model.prediction_head.residue_diff.parameters():
        parameter.requires_grad = True


def set_residual_training_mode(model):
    """Keep frozen V1 deterministic while enabling dropout in the local branch."""
    model.eval()
    model.prediction_head.residue_diff.train()


def regression_with_sign_loss(pred_delta, true_delta, lambda_sign=0.1,
                              sign_threshold=0.5, temperature=1.0):
    """Combine delta regression with sign classification for large effects."""
    if lambda_sign < 0:
        raise ValueError('lambda_sign must be non-negative')
    if sign_threshold < 0:
        raise ValueError('sign_threshold must be non-negative')
    if temperature <= 0:
        raise ValueError('temperature must be positive')

    loss_reg = F.mse_loss(pred_delta, true_delta)
    if lambda_sign == 0:
        return loss_reg, {
            'loss_reg': loss_reg.detach(),
            'loss_sign': pred_delta.new_tensor(0.0),
        }

    mask = true_delta.abs() >= sign_threshold
    if mask.any():
        sign_target = (true_delta[mask] > 0).float()
        sign_logits = pred_delta[mask] / temperature
        loss_sign = F.binary_cross_entropy_with_logits(
            sign_logits, sign_target
        )
    else:
        loss_sign = pred_delta.new_tensor(0.0)

    loss = loss_reg + lambda_sign * loss_sign
    return loss, {
        'loss_reg': loss_reg.detach(),
        'loss_sign': loss_sign.detach(),
    }


def residual_training_loss(output, y_true, lambda_sign=0.1,
                           sign_threshold=0.5, temperature=1.0):
    """Train the residual branch using the complete delta prediction."""
    loss, stats = regression_with_sign_loss(
        output['pred'], y_true, lambda_sign, sign_threshold, temperature
    )
    stats['train_mean_abs_delta_local'] = (
        output['delta_local'].abs().mean().detach()
    )
    return loss, stats


class SharedLigandKinaseScorerV1(nn.Module):
    """Shared latent compatibility scorer over ligand and global ESM features."""

    def __init__(self, ligand_dim=128, esm_dim=1280, hidden1=1024,
                 hidden2=512, dropout=0.2):
        super().__init__()
        self.ligand_dim = ligand_dim
        self.esm_dim = esm_dim
        self.net = nn.Sequential(
            nn.Linear(ligand_dim + esm_dim, hidden1),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden1, hidden2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden2, 1, bias=False),
        )

    def forward(self, ligand_emb, kinase_global_emb):
        if ligand_emb.ndim != 2 or ligand_emb.size(1) != self.ligand_dim:
            raise ValueError(
                f'Expected ligand embeddings with shape [batch, {self.ligand_dim}]'
            )
        if (kinase_global_emb.ndim != 2
                or kinase_global_emb.size(1) != self.esm_dim):
            raise ValueError(
                f'Expected ESM embeddings with shape [batch, {self.esm_dim}]'
            )
        if ligand_emb.size(0) != kinase_global_emb.size(0):
            raise ValueError('Ligand and protein batch sizes differ')
        return self.net(torch.cat((ligand_emb, kinase_global_emb), dim=-1))


class SharedResidueLevelScorer(nn.Module):
    """Archived shared-scorer branch retained for experiment comparison."""

    def __init__(self, ligand_dim=128, esm_dim=1280, residue_dim=64,
                 attn_hidden=64, local_hidden=128, dropout=0.2, top_k=None,
                 zero_init_output=True):
        super().__init__()
        if top_k is not None and top_k < 0:
            raise ValueError('top_k must be non-negative or None')
        self.ligand_dim = ligand_dim
        self.esm_dim = esm_dim
        self.residue_dim = residue_dim
        self.top_k = None if top_k in (None, 0) else int(top_k)
        self.register_buffer(
            '_top_k_value', torch.tensor(self.top_k or 0, dtype=torch.long)
        )
        self.residue_proj = nn.Sequential(
            nn.Linear(esm_dim, residue_dim),
            nn.LayerNorm(residue_dim),
            nn.GELU(),
        )
        self.ligand_proj = nn.Sequential(
            nn.Linear(ligand_dim, residue_dim),
            nn.LayerNorm(residue_dim),
            nn.GELU(),
        )
        self.attn = nn.Sequential(
            nn.Linear(residue_dim * 2, attn_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(attn_hidden, 1),
        )
        self.local_scorer = nn.Sequential(
            nn.Linear(ligand_dim + residue_dim, local_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(local_hidden, local_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(local_hidden, 1, bias=False),
        )
        if zero_init_output:
            nn.init.zeros_(self.local_scorer[-1].weight)

    def _validate_single_inputs(self, ligand_emb, residue, valid_mask,
                                projected=False):
        expected_dim = self.residue_dim if projected else self.esm_dim
        if residue.ndim != 3 or residue.size(2) != expected_dim:
            label = 'projected residue' if projected else 'residue embedding'
            raise ValueError(
                f'Expected {label} shape [batch, length, {expected_dim}]'
            )
        if ligand_emb.ndim != 2 or ligand_emb.size(1) != self.ligand_dim:
            raise ValueError(
                f'Expected ligand embeddings with shape [batch, {self.ligand_dim}]'
            )
        if ligand_emb.size(0) != residue.size(0):
            raise ValueError('Ligand and residue batch sizes differ')
        if valid_mask.shape != residue.shape[:2]:
            raise ValueError(f'Expected valid_mask shape {residue.shape[:2]}')

    def _apply_optional_topk(self, logits, valid_mask):
        if self.top_k is None:
            return logits
        k = min(self.top_k, logits.size(1))
        if k >= logits.size(1):
            return logits
        top_indices = torch.topk(logits, k=k, dim=1).indices
        keep = torch.zeros_like(valid_mask, dtype=torch.bool)
        keep.scatter_(1, top_indices, True)
        keep &= valid_mask
        return logits.masked_fill(~keep, torch.finfo(logits.dtype).min)

    def score_single(self, ligand_emb, residue, valid_mask):
        self._validate_single_inputs(ligand_emb, residue, valid_mask)
        return self.score_single_projected(
            ligand_emb, self.residue_proj(residue), valid_mask
        )

    def score_single_projected(self, ligand_emb, residue_h, valid_mask):
        self._validate_single_inputs(
            ligand_emb, residue_h, valid_mask, projected=True
        )
        valid_mask = valid_mask.bool()
        ligand_h = self.ligand_proj(ligand_emb)
        ligand_h = ligand_h.unsqueeze(1).expand(-1, residue_h.size(1), -1)
        logits = self.attn(torch.cat((residue_h, ligand_h), dim=-1)).squeeze(-1)
        logits = logits.masked_fill(
            ~valid_mask, torch.finfo(logits.dtype).min
        )
        logits = self._apply_optional_topk(logits, valid_mask)
        has_valid = valid_mask.any(dim=1, keepdim=True)
        weights = torch.softmax(logits, dim=1)
        weights = torch.where(has_valid, weights, torch.zeros_like(weights))
        pooled = torch.sum(weights.unsqueeze(-1) * residue_h, dim=1)
        score = self.local_scorer(torch.cat((ligand_emb, pooled), dim=-1))
        return score, weights, pooled

    def _paired_outputs(self, ligand_emb, residue_a, residue_b, valid_mask,
                        projected):
        scorer = (self.score_single_projected if projected
                  else self.score_single)
        score_a, weights_a, pooled_a = scorer(
            ligand_emb, residue_a, valid_mask
        )
        score_b, weights_b, pooled_b = scorer(
            ligand_emb, residue_b, valid_mask
        )
        return {
            'delta_local': score_a - score_b,
            'score_local_a': score_a,
            'score_local_b': score_b,
            'attn_weights_a': weights_a,
            'attn_weights_b': weights_b,
            'pooled_a': pooled_a,
            'pooled_b': pooled_b,
        }

    def forward(self, ligand_emb, residue_a, residue_b, valid_mask,
                mismatch_mask=None):
        self._validate_pair(residue_a, residue_b, valid_mask, mismatch_mask)
        return self._paired_outputs(
            ligand_emb, residue_a, residue_b, valid_mask, projected=False
        )

    def forward_projected(self, ligand_emb, residue_a, residue_b, valid_mask,
                          mismatch_mask=None):
        self._validate_pair(residue_a, residue_b, valid_mask, mismatch_mask)
        return self._paired_outputs(
            ligand_emb, residue_a, residue_b, valid_mask, projected=True
        )

    @staticmethod
    def _validate_pair(residue_a, residue_b, valid_mask, mismatch_mask):
        if residue_a.ndim != 3 or residue_b.shape != residue_a.shape:
            raise ValueError(
                'Expected paired residue embeddings with identical shape '
                '[batch, length, dim]'
            )
        expected_shape = residue_a.shape[:2]
        if valid_mask.shape != expected_shape:
            raise ValueError(f'Expected valid_mask shape {expected_shape}')
        if mismatch_mask is not None and mismatch_mask.shape != expected_shape:
            raise ValueError(f'Expected mismatch_mask shape {expected_shape}')


class ESMSharedDifferenceHead(nn.Module):
    """Frozen V1 difference plus the aligned residue-difference branch."""

    def __init__(self, ligand_dim=128, esm_dim=1280, shared_hidden1=1024,
                 shared_hidden2=512, residue_dim=256, attn_hidden=256,
                 local_hidden=256, dropout=0.2, residue_top_k=None,
                 zero_init_local_output=True):
        super().__init__()
        if residue_top_k not in (None, 0):
            raise ValueError(
                'residue_top_k is unavailable for the residue-difference branch'
            )
        self.esm_dim = esm_dim
        self.shared_scorer = SharedLigandKinaseScorerV1(
            ligand_dim=ligand_dim,
            esm_dim=esm_dim,
            hidden1=shared_hidden1,
            hidden2=shared_hidden2,
            dropout=dropout,
        )
        self.residue_diff = AntisymmetricResidueDiffBranch(
            ligand_dim=ligand_dim,
            esm_dim=esm_dim,
            residue_dim=residue_dim,
            attn_hidden=attn_hidden,
            local_hidden=local_hidden,
            dropout=dropout,
        )
        self.register_buffer(
            'local_scale', torch.tensor(1.0, dtype=torch.float32),
            persistent=True,
        )

    def forward(self, ligand_emb, esm_global_a, esm_global_b, residue_a,
                residue_b, valid_mask, mismatch_mask, return_aux=False):
        if (esm_global_a.ndim != 2 or esm_global_b.shape != esm_global_a.shape
                or esm_global_a.size(1) != self.esm_dim):
            raise ValueError(
                f'Expected paired ESM embeddings with shape [batch, {self.esm_dim}]'
            )
        score_a = self.shared_scorer(ligand_emb, esm_global_a)
        score_b = self.shared_scorer(ligand_emb, esm_global_b)
        delta_shared = score_a - score_b
        local = self.residue_diff(
            ligand_emb, residue_a, residue_b, valid_mask, mismatch_mask
        )
        return self._outputs(delta_shared, local, return_aux)

    def forward_projected_residues(
            self, ligand_emb, esm_global_a, esm_global_b, residue_a,
            residue_b, valid_mask, mismatch_mask, return_aux=False):
        if (esm_global_a.ndim != 2 or esm_global_b.shape != esm_global_a.shape
                or esm_global_a.size(1) != self.esm_dim):
            raise ValueError(
                f'Expected paired ESM embeddings with shape [batch, {self.esm_dim}]'
            )
        score_a = self.shared_scorer(ligand_emb, esm_global_a)
        score_b = self.shared_scorer(ligand_emb, esm_global_b)
        delta_shared = score_a - score_b
        local = self.residue_diff.forward_projected(
            ligand_emb, residue_a, residue_b, valid_mask, mismatch_mask
        )
        return self._outputs(delta_shared, local, return_aux)

    def _outputs(self, delta_shared, local, return_aux):
        delta_local, attention, pooled_diff = local
        prediction = delta_shared.detach() + self.local_scale * delta_local
        if return_aux:
            return {
                'pred': prediction,
                'delta_shared': delta_shared,
                'delta_local': delta_local,
                'local_scale': self.local_scale,
                'attn_weights': attention,
                'pooled_diff': pooled_diff,
            }
        return prediction

    def forward_batch(self, ligand_emb, data, return_aux=False):
        """Score a collated batch, projecting each unique kinase once."""
        if hasattr(data, 'unique_esm_residue'):
            projected = self.residue_diff.residue_proj(
                data.unique_esm_residue.float()
            )
            residue_a, residue_b, valid_mask, mismatch_mask = (
                dense_projected_residue_inputs(data, projected)
            )
            return self.forward_projected_residues(
                ligand_emb, data.esm_A, data.esm_B, residue_a, residue_b,
                valid_mask, mismatch_mask, return_aux=return_aux,
            )

        residue_a, residue_b, valid_mask, mismatch_mask = dense_residue_inputs(data)
        return self(
            ligand_emb, data.esm_A, data.esm_B, residue_a, residue_b,
            valid_mask, mismatch_mask, return_aux=return_aux,
        )


def dense_projected_residue_inputs(data, projected_residues):
    """Gather per-kinase projections into padded aligned pair tensors."""
    required = (
        'unique_residue_length', 'kinase_A_unique', 'kinase_B_unique',
        'residue_position_A', 'residue_position_B',
        'residue_mismatch_mask', 'residue_length',
    )
    missing = [name for name in required if not hasattr(data, name)]
    if missing:
        raise ValueError(f'Missing deduplicated residue inputs {missing}')

    unique_lengths = data.unique_residue_length.view(-1).long()
    pair_lengths = data.residue_length.view(-1).long()
    if torch.any(unique_lengths <= 0) or torch.any(pair_lengths <= 0):
        raise ValueError('Residue lengths must be positive')
    if projected_residues.size(0) != int(unique_lengths.sum().item()):
        raise ValueError('Unique residue lengths do not match projected residues')

    unique_offsets = torch.cat((
        unique_lengths.new_zeros(1), unique_lengths.cumsum(0)[:-1]
    ))
    base_a = torch.repeat_interleave(
        unique_offsets[data.kinase_A_unique.view(-1).long()], pair_lengths
    )
    base_b = torch.repeat_interleave(
        unique_offsets[data.kinase_B_unique.view(-1).long()], pair_lengths
    )
    position_a = data.residue_position_A.view(-1).long()
    position_b = data.residue_position_B.view(-1).long()
    expected_rows = int(pair_lengths.sum().item())
    if position_a.numel() != expected_rows or position_b.numel() != expected_rows:
        raise ValueError('Pair residue lengths do not match alignment positions')

    aligned_a = projected_residues[base_a + position_a]
    aligned_b = projected_residues[base_b + position_b]
    residue_batch = torch.repeat_interleave(
        torch.arange(pair_lengths.numel(), device=pair_lengths.device),
        pair_lengths,
    )
    residue_a, present_a = to_dense_batch(
        aligned_a, residue_batch, batch_size=pair_lengths.numel()
    )
    residue_b, present_b = to_dense_batch(
        aligned_b, residue_batch, batch_size=pair_lengths.numel()
    )
    mismatch_mask, present_mismatch = to_dense_batch(
        data.residue_mismatch_mask.view(-1), residue_batch,
        batch_size=pair_lengths.numel(),
    )
    if not (torch.equal(present_a, present_b)
            and torch.equal(present_a, present_mismatch)):
        raise ValueError('Inconsistent projected residue input lengths')
    return residue_a, residue_b, present_a, mismatch_mask.bool()


def dense_residue_inputs(data):
    """Convert PyG-concatenated aligned residues back to padded batch tensors."""
    required = ('esm_residue_A', 'esm_residue_B', 'residue_valid_mask',
                'residue_mismatch_mask', 'residue_length')
    missing = [name for name in required if not hasattr(data, name)]
    if missing:
        raise ValueError(
            f'Missing V2 residue inputs {missing}; regenerate the ESM cache with '
            'scripts/precompute_esm.py'
        )
    lengths = data.residue_length.view(-1).long()
    if torch.any(lengths <= 0):
        raise ValueError('Aligned residue lengths must be positive')
    batch_size = lengths.numel()
    residue_batch = torch.repeat_interleave(
        torch.arange(batch_size, device=lengths.device), lengths
    )
    expected_rows = int(lengths.sum().item())
    if data.esm_residue_A.size(0) != expected_rows:
        raise ValueError('Residue lengths do not match the concatenated residue inputs')

    residue_a, present = to_dense_batch(
        data.esm_residue_A, residue_batch, batch_size=batch_size
    )
    residue_b, present_b = to_dense_batch(
        data.esm_residue_B, residue_batch, batch_size=batch_size
    )
    valid_mask, present_valid = to_dense_batch(
        data.residue_valid_mask, residue_batch, batch_size=batch_size
    )
    mismatch_mask, present_mismatch = to_dense_batch(
        data.residue_mismatch_mask, residue_batch, batch_size=batch_size
    )
    if not (torch.equal(present, present_b)
            and torch.equal(present, present_valid)
            and torch.equal(present, present_mismatch)):
        raise ValueError('Inconsistent batched residue input lengths')
    return residue_a, residue_b, valid_mask.bool(), mismatch_mask.bool()


@torch.no_grad()
def check_antisymmetry(model, ligand_emb, esm_global_a, esm_global_b,
                       residue_a, residue_b, valid_mask, mismatch_mask):
    """Return numerical A/B swap errors for a V2 difference head."""
    model.eval()
    pred_ab = model(
        ligand_emb, esm_global_a, esm_global_b, residue_a, residue_b,
        valid_mask, mismatch_mask,
    )
    pred_ba = model(
        ligand_emb, esm_global_b, esm_global_a, residue_b, residue_a,
        valid_mask, mismatch_mask,
    )
    error = torch.abs(pred_ab + pred_ba)
    return {
        'max_abs_error': float(error.max().cpu()),
        'mean_abs_error': float(error.mean().cpu()),
    }


ESMPairDifferenceHead = ESMSharedDifferenceHead
ESMPairHead = ESMSharedDifferenceHead
ESMSharedResidueHead = ESMSharedDifferenceHead
