import torch
from torch import nn


class AntisymmetricResidueDiffBranch(nn.Module):
    """Archived aligned residue-difference branch with exact odd symmetry."""

    def __init__(self, ligand_dim=128, esm_dim=1280, residue_dim=256,
                 attn_hidden=256, local_hidden=256, dropout=0.2):
        super().__init__()
        self.ligand_dim = ligand_dim
        self.esm_dim = esm_dim
        self.residue_proj = nn.Sequential(
            nn.Linear(esm_dim, residue_dim),
            nn.LayerNorm(residue_dim),
            nn.GELU(),
        )
        self.ligand_proj = nn.Sequential(
            nn.Linear(ligand_dim, residue_dim),
            nn.LayerNorm(residue_dim),
            nn.GELU(),
        )
        self.attn = nn.Sequential(
            nn.Linear(residue_dim * 2 + 1, attn_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(attn_hidden, 1),
        )
        self.local_scorer = nn.Sequential(
            nn.Linear(ligand_dim + residue_dim, local_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(local_hidden, local_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(local_hidden, 1, bias=False),
        )

    def _score_local(self, ligand_emb, diff_vec):
        return self.local_scorer(torch.cat((ligand_emb, diff_vec), dim=-1))

    def forward(self, ligand_emb, residue_a, residue_b, valid_mask,
                mismatch_mask):
        if residue_a.ndim != 3 or residue_b.shape != residue_a.shape:
            raise ValueError(
                'Expected paired residue embeddings with shape '
                '[batch, length, esm_dim]'
            )
        if residue_a.size(2) != self.esm_dim:
            raise ValueError(f'Expected residue embedding dimension {self.esm_dim}')
        if ligand_emb.ndim != 2 or ligand_emb.size(1) != self.ligand_dim:
            raise ValueError(
                f'Expected ligand embeddings with shape [batch, {self.ligand_dim}]'
            )
        expected_mask_shape = residue_a.shape[:2]
        if valid_mask.shape != expected_mask_shape:
            raise ValueError(f'Expected valid_mask shape {expected_mask_shape}')
        if mismatch_mask.shape != expected_mask_shape:
            raise ValueError(f'Expected mismatch_mask shape {expected_mask_shape}')

        a = self.residue_proj(residue_a)
        b = self.residue_proj(residue_b)
        return self.forward_projected(
            ligand_emb, a, b, valid_mask, mismatch_mask
        )

    def forward_projected(self, ligand_emb, a, b, valid_mask, mismatch_mask):
        """Score aligned residues that have already passed residue_proj."""
        if a.ndim != 3 or b.shape != a.shape:
            raise ValueError(
                'Expected projected residues with shape '
                '[batch, length, residue_dim]'
            )
        if a.size(2) != self.residue_proj[0].out_features:
            raise ValueError('Unexpected projected residue dimension')
        if ligand_emb.ndim != 2 or ligand_emb.size(1) != self.ligand_dim:
            raise ValueError(
                f'Expected ligand embeddings with shape [batch, {self.ligand_dim}]'
            )
        expected_mask_shape = a.shape[:2]
        if valid_mask.shape != expected_mask_shape:
            raise ValueError(f'Expected valid_mask shape {expected_mask_shape}')
        if mismatch_mask.shape != expected_mask_shape:
            raise ValueError(f'Expected mismatch_mask shape {expected_mask_shape}')

        signed_diff = a - b
        abs_diff = torch.abs(signed_diff)
        ligand_local = self.ligand_proj(ligand_emb)
        ligand_local = ligand_local.unsqueeze(1).expand(-1, a.size(1), -1)
        mismatch = mismatch_mask.to(dtype=a.dtype).unsqueeze(-1)
        logits = self.attn(
            torch.cat((abs_diff, ligand_local, mismatch), dim=-1)
        ).squeeze(-1)

        valid_mask = valid_mask.bool()
        logits = logits.masked_fill(~valid_mask, torch.finfo(logits.dtype).min)
        has_valid = valid_mask.any(dim=1, keepdim=True)
        weights = torch.softmax(logits, dim=1)
        weights = torch.where(has_valid, weights, torch.zeros_like(weights))
        pooled_signed_diff = torch.sum(
            weights.unsqueeze(-1) * signed_diff, dim=1
        )
        pos = self._score_local(ligand_emb, pooled_signed_diff)
        neg = self._score_local(ligand_emb, -pooled_signed_diff)
        local_delta = 0.5 * (pos - neg)
        return local_delta, weights, pooled_signed_diff
