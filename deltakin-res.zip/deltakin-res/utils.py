import torch
import numpy as np
from math import sqrt
from scipy import stats
import os
from torch_geometric import data as DATA
from torch_geometric.data import Batch, InMemoryDataset
from torch_geometric.loader import DataLoader
from torch.utils.data import DataLoader as TorchDataLoader


class ESMEmbeddingTransform:
    """Attach cached global and optionally aligned residue ESM features."""

    def __init__(self, path, require_residue=False):
        if not os.path.isfile(path):
            raise FileNotFoundError(f'{path} not found; run python scripts/precompute_esm.py first')
        cache = torch.load(path, map_location='cpu', weights_only=False)
        if cache['model'] != 'esm2_t33_650M_UR50D':
            raise ValueError('Expected ESM2 t33 650M embeddings')
        self.dim = cache['dim']
        self.embeddings = cache['embeddings']
        for kinase, embedding in self.embeddings.items():
            if embedding.shape != (self.dim,) or not torch.isfinite(embedding).all():
                raise ValueError(f'Invalid ESM embedding for kinase {kinase}')

        self.require_residue = require_residue
        self.sequences = cache.get('sequences')
        self.residue_embeddings = cache.get('residue_embeddings')
        self._alignment_cache = {}
        self._aligner = None
        if require_residue:
            if self.sequences is None or self.residue_embeddings is None:
                raise ValueError(
                    f'{path} contains global ESM embeddings only; regenerate it '
                    'with the current scripts/precompute_esm.py for difference_v2'
                )
            if set(self.sequences) != set(self.embeddings):
                raise ValueError('ESM cache sequence and global embedding IDs differ')
            if set(self.residue_embeddings) != set(self.embeddings):
                raise ValueError('ESM cache residue and global embedding IDs differ')
            for kinase, residue_embedding in self.residue_embeddings.items():
                expected = (len(self.sequences[kinase]), self.dim)
                if (residue_embedding.shape != expected
                        or not torch.isfinite(residue_embedding).all()):
                    raise ValueError(
                        f'Invalid residue ESM embedding for kinase {kinase}; '
                        f'expected {expected}'
                    )

    def _get_aligner(self):
        if self._aligner is None:
            try:
                from Bio.Align import PairwiseAligner
            except ImportError as exc:
                raise ImportError(
                    'difference_v2 residue alignment requires biopython'
                ) from exc
            aligner = PairwiseAligner()
            aligner.mode = 'global'
            aligner.match_score = 2.0
            aligner.mismatch_score = -1.0
            aligner.open_gap_score = -5.0
            aligner.extend_gap_score = -0.5
            self._aligner = aligner
        return self._aligner

    def _canonical_alignment(self, kinase_a, kinase_b):
        key = tuple(sorted((kinase_a, kinase_b)))
        if key not in self._alignment_cache:
            sequence_0 = self.sequences[key[0]]
            sequence_1 = self.sequences[key[1]]
            if key[0] == key[1]:
                indices_0 = torch.arange(len(sequence_0), dtype=torch.long)
                indices_1 = indices_0.clone()
            else:
                alignment = next(self._get_aligner().align(sequence_0, sequence_1))
                indices_0 = torch.from_numpy(alignment.indices[0].copy()).long()
                indices_1 = torch.from_numpy(alignment.indices[1].copy()).long()
            valid = indices_0.ge(0) & indices_1.ge(0)
            mismatch = torch.zeros(indices_0.numel(), dtype=torch.bool)
            mismatch[valid] = torch.tensor([
                sequence_0[index_0] != sequence_1[index_1]
                for index_0, index_1 in zip(
                    indices_0[valid].tolist(), indices_1[valid].tolist()
                )
            ], dtype=torch.bool)
            self._alignment_cache[key] = (indices_0, indices_1, valid, mismatch)

        indices_0, indices_1, valid, mismatch = self._alignment_cache[key]
        if kinase_a == key[0]:
            return indices_0, indices_1, valid, mismatch
        return indices_1, indices_0, valid, mismatch

    def _aligned_positions(self, kinase_a, kinase_b):
        indices_a, indices_b, valid, mismatch = self._canonical_alignment(
            kinase_a, kinase_b
        )
        return indices_a[valid], indices_b[valid], mismatch[valid]

    def __call__(self, data):
        try:
            data.esm_A = self.embeddings[data.kinase_A_id].unsqueeze(0)
            data.esm_B = self.embeddings[data.kinase_B_id].unsqueeze(0)
        except KeyError as exc:
            raise KeyError(f'Kinase {exc} missing from ESM cache') from exc
        if self.require_residue:
            position_a, position_b, mismatch = self._aligned_positions(
                data.kinase_A_id, data.kinase_B_id
            )
            data.residue_position_A = position_a
            data.residue_position_B = position_b
            data.residue_mismatch_mask = mismatch
            data.residue_length = torch.tensor(
                [position_a.numel()], dtype=torch.long
            )
        return data


class ESMPairBatchCollater:
    """Build a PyG batch with one residue tensor per unique kinase."""

    def __init__(self, esm_transform):
        self.esm_transform = esm_transform

    def __call__(self, samples):
        batch = Batch.from_data_list(samples)
        if not self.esm_transform.require_residue:
            return batch

        unique_kinases = []
        kinase_to_unique = {}
        kinase_a_unique = []
        kinase_b_unique = []
        for sample in samples:
            sample_indices = []
            for kinase in (sample.kinase_A_id, sample.kinase_B_id):
                if kinase not in kinase_to_unique:
                    kinase_to_unique[kinase] = len(unique_kinases)
                    unique_kinases.append(kinase)
                sample_indices.append(kinase_to_unique[kinase])
            kinase_a_unique.append(sample_indices[0])
            kinase_b_unique.append(sample_indices[1])

        residues = [
            self.esm_transform.residue_embeddings[kinase]
            for kinase in unique_kinases
        ]
        batch.unique_esm_residue = torch.cat(residues, dim=0)
        batch.unique_residue_length = torch.tensor(
            [residue.size(0) for residue in residues], dtype=torch.long
        )
        batch.kinase_A_unique = torch.tensor(kinase_a_unique, dtype=torch.long)
        batch.kinase_B_unique = torch.tensor(kinase_b_unique, dtype=torch.long)
        return batch


def make_pair_data_loader(dataset, batch_size, esm_transform, shuffle=False,
                          generator=None, num_workers=0, pin_memory=False):
    """Create a loader that deduplicates residue tensors within each batch."""
    if isinstance(num_workers, bool) or num_workers < 0:
        raise ValueError('num_workers must be a non-negative integer')
    kwargs = {
        'dataset': dataset,
        'batch_size': batch_size,
        'shuffle': shuffle,
        'generator': generator,
        'num_workers': num_workers,
        'pin_memory': pin_memory,
        'collate_fn': ESMPairBatchCollater(esm_transform),
    }
    if num_workers > 0:
        kwargs.update(persistent_workers=True, prefetch_factor=2)
    return TorchDataLoader(**kwargs)

class SiameseTestbedDataset(InMemoryDataset):
    def __init__(self, root='/tmp', dataset='selectivity_train',
                 xd=None, xt_A=None, xt_B=None, y=None, smile_graph=None,
                 compound_ids=None, kinase_A_ids=None, kinase_B_ids=None,
                 max_seq_len=108,
                 transform=None, pre_transform=None,
                 smiles_strings=None, source_rows=None):

        super(SiameseTestbedDataset, self).__init__(root, transform, pre_transform)
        self.dataset = dataset
        self.max_seq_len = max_seq_len

        if os.path.isfile(self.processed_paths[0]):
            print(f"  Loading pre-processed {dataset}...")
            self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)
        else:
            if xd is None:
                raise FileNotFoundError(
                    f"{self.processed_paths[0]} not found. "
                    f"Run the preprocessing script for this dataset first."
                )
            print(f"  Processing {dataset}...")
            self.process(xd, xt_A, xt_B, y, smile_graph,
                         compound_ids, kinase_A_ids, kinase_B_ids,
                         smiles_strings, source_rows)
            self.data, self.slices = torch.load(self.processed_paths[0], weights_only=False)

    @property
    def raw_file_names(self):
        pass

    @property
    def processed_file_names(self):
        return [self.dataset + '.pt']

    def download(self):
        pass

    def _download(self):
        pass

    def _process(self):
        if not os.path.exists(self.processed_dir):
            os.makedirs(self.processed_dir)

    def process(self, xd, xt_A, xt_B, y, smile_graph,
                compound_ids, kinase_A_ids, kinase_B_ids,
                smiles_strings, source_rows):
        assert len(xd) == len(y), "Mismatched graph and label lengths"
        if (xt_A is None) != (xt_B is None):
            raise ValueError('Both sequence arrays must be provided together')
        if xt_A is not None:
            assert len(xd) == len(xt_A) == len(xt_B), 'Mismatched sequence lengths'
        if smiles_strings is not None and len(smiles_strings) != len(xd):
            raise ValueError('Mismatched SMILES lengths')
        if source_rows is not None and len(source_rows) != len(xd):
            raise ValueError('Mismatched source row lengths')

        data_list = []
        for i in range(len(xd)):
            smiles = xd[i]
            label = y[i]
            c_size, features, edge_index = smile_graph[smiles]

            if len(edge_index) == 0:
                edge_idx = torch.empty((2, 0), dtype=torch.long)
            else:
                edge_idx = torch.LongTensor(np.array(edge_index)).transpose(1, 0)

            GCNData = DATA.Data(
                x=torch.FloatTensor(np.array(features)),
                edge_index=edge_idx,
                y=torch.FloatTensor([label]),
            )
            GCNData.__setattr__('c_size', torch.LongTensor([c_size]))

            if xt_A is not None:
                GCNData.target_A = torch.ShortTensor(xt_A[i].astype(np.int16))
                GCNData.target_B = torch.ShortTensor(xt_B[i].astype(np.int16))

            # IDs for inference output
            GCNData.compound_id = str(compound_ids[i])
            GCNData.kinase_A_id = str(kinase_A_ids[i])
            GCNData.kinase_B_id = str(kinase_B_ids[i])
            if smiles_strings is not None:
                GCNData.smiles = str(smiles_strings[i])
            if source_rows is not None:
                GCNData.source_row = int(source_rows[i])

            data_list.append(GCNData)

            if (i + 1) % 100000 == 0:
                print(f"    {i+1}/{len(xd)} samples processed...")

        if self.pre_filter is not None:
            data_list = [d for d in data_list if self.pre_filter(d)]
        if self.pre_transform is not None:
            data_list = [self.pre_transform(d) for d in data_list]

        print(f"  Saving {len(data_list)} samples...")
        data, slices = self.collate(data_list)
        torch.save((data, slices), self.processed_paths[0])

def rmse(y,f):
    rmse = sqrt(((y - f)**2).mean(axis=0))
    return rmse
def mse(y,f):
    mse = ((y - f)**2).mean(axis=0)
    return mse


def mae(y, f):
    y, f = _metric_arrays(y, f)
    return float(np.abs(y - f).mean(dtype=np.float64))


def _metric_arrays(y, f):
    y = np.ascontiguousarray(y, dtype=np.float64).reshape(-1).copy()
    f = np.ascontiguousarray(f, dtype=np.float64).reshape(-1).copy()
    if y.shape != f.shape:
        raise ValueError(f'Metric arrays have different shapes: {y.shape} and {f.shape}')
    if y.size < 2:
        raise ValueError('Correlation metrics require at least two samples')
    if not np.isfinite(y).all() or not np.isfinite(f).all():
        raise ValueError('Correlation metrics received NaN or infinite values')
    return y, f


def _centered_pearson(y, f):
    y_centered = y - y.mean(dtype=np.float64)
    f_centered = f - f.mean(dtype=np.float64)
    numerator = np.sum(y_centered * f_centered, dtype=np.float64)
    denominator = sqrt(
        np.sum(y_centered * y_centered, dtype=np.float64)
        * np.sum(f_centered * f_centered, dtype=np.float64)
    )
    return float(numerator / denominator) if denominator > 0 else float('nan')


def pearson(y,f):
    y, f = _metric_arrays(y, f)
    return _centered_pearson(y, f)


def spearman(y,f):
    y, f = _metric_arrays(y, f)
    return _centered_pearson(stats.rankdata(y, method='average'),
                             stats.rankdata(f, method='average'))


def direction_accuracy(y, f, min_abs_label=0.0):
    """Return sign accuracy after excluding ties and small true effects."""
    y, f = _metric_arrays(y, f)
    if (not isinstance(min_abs_label, (int, float))
            or not np.isfinite(min_abs_label) or min_abs_label < 0):
        raise ValueError('min_abs_label must be a finite non-negative number')
    selected = (np.abs(y) > 1e-12) & (np.abs(y) >= min_abs_label)
    if not selected.any():
        return float('nan')
    return float(np.mean(np.sign(y[selected]) == np.sign(f[selected])))


def direction_sample_count(y, min_abs_label=0.0):
    """Count non-tied labels included in a direction-accuracy metric."""
    y = np.ascontiguousarray(y, dtype=np.float64).reshape(-1)
    if not np.isfinite(y).all():
        raise ValueError('Direction labels received NaN or infinite values')
    if (not isinstance(min_abs_label, (int, float))
            or not np.isfinite(min_abs_label) or min_abs_label < 0):
        raise ValueError('min_abs_label must be a finite non-negative number')
    return int(((np.abs(y) > 1e-12) & (np.abs(y) >= min_abs_label)).sum())


def ci(y,f):
    ind = np.argsort(y)
    y = y[ind]
    f = f[ind]
    i = len(y)-1
    j = i-1
    z = 0.0
    S = 0.0
    while i > 0:
        while j >= 0:
            if y[i] > y[j]:
                z = z+1
                u = f[i] - f[j]
                if u > 0:
                    S = S + 1
                elif u == 0:
                    S = S + 0.5
            j = j - 1
        i = i - 1
        j = i-1
    ci = S/z
    return ci
