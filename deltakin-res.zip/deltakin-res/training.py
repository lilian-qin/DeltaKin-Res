import torch
import numpy as np
import random
from torch.utils.data import Subset
import pandas as pd
import json
import argparse
from pathlib import Path
from datetime import datetime
from models.gat_gcn_pair import GAT_GCN
from models.esm_pair import (
    freeze_pretrained_v1,
    load_pretrained_v1,
    regression_with_sign_loss,
    residual_training_loss,
    set_residual_training_mode,
)
from models.shared_difference_v1 import GAT_GCN as DifferenceV1GAT_GCN
from scripts.split import load_split
from utils import *


DEFAULT_TRAINING_CONFIG = Path(__file__).resolve().parent / 'configs' / 'training.json'


def load_training_config(config_path, cli_overrides=None):
    """Load and validate training hyperparameters from JSON."""
    with DEFAULT_TRAINING_CONFIG.open() as f:
        defaults = json.load(f)

    config_path = Path(config_path)
    if config_path.resolve() == DEFAULT_TRAINING_CONFIG.resolve():
        config = defaults
    else:
        with config_path.open() as f:
            overrides = json.load(f)
        unknown_keys = sorted(set(overrides) - set(defaults))
        if unknown_keys:
            raise ValueError(f'Unknown training config keys: {unknown_keys}')
        config = {**defaults, **overrides}

    if cli_overrides:
        config.update({key: value for key, value in cli_overrides.items()
                       if value is not None})

    positive_ints = (
        'train_batch_size', 'eval_batch_size', 'num_epochs', 'patience',
        'log_interval', 'residue_dim', 'attn_hidden', 'local_hidden',
    )
    for key in positive_ints:
        value = config[key]
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f'{key} must be a positive integer, got {value!r}')

    num_workers = config['num_workers']
    if (isinstance(num_workers, bool) or not isinstance(num_workers, int)
            or num_workers < 0):
        raise ValueError(
            f'num_workers must be a non-negative integer, got {num_workers!r}'
        )
    residue_top_k = config['residue_top_k']
    if (isinstance(residue_top_k, bool)
            or not isinstance(residue_top_k, int) or residue_top_k < 0):
        raise ValueError('residue_top_k must be a non-negative integer')

    if not isinstance(config['learning_rate'], (int, float)) or config['learning_rate'] <= 0:
        raise ValueError('learning_rate must be positive')
    if not isinstance(config['weight_decay'], (int, float)) or config['weight_decay'] < 0:
        raise ValueError('weight_decay must be non-negative')
    if (not isinstance(config['dropout'], (int, float))
            or not 0 <= config['dropout'] < 1):
        raise ValueError('dropout must be in [0, 1)')
    non_negative_floats = ('lambda_sign', 'sign_threshold')
    for key in non_negative_floats:
        value = config[key]
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not np.isfinite(value) or value < 0):
            raise ValueError(f'{key} must be a finite non-negative number')
    temperature = config['temperature']
    if (isinstance(temperature, bool)
            or not isinstance(temperature, (int, float))
            or not np.isfinite(temperature) or temperature <= 0):
        raise ValueError('temperature must be a finite positive number')
    if not isinstance(config['save_validation_predictions'], bool):
        raise ValueError('save_validation_predictions must be true or false')
    if not isinstance(config['pin_memory'], bool):
        raise ValueError('pin_memory must be true or false')
    return config


# ============================================================
# Training / evaluation functions
# ============================================================

def train(model, device, train_loader, optimizer, epoch,
          residual_training=False, lambda_sign=0.1, sign_threshold=0.5,
          temperature=1.0):
    print('Training on {} samples...'.format(len(train_loader.dataset)))
    if residual_training:
        set_residual_training_mode(model)
    else:
        model.train()
    grad_norms = []
    training_stats = {}
    sample_count = 0
    for batch_idx, data in enumerate(train_loader):
        data = data.to(
            device, non_blocking=(PIN_MEMORY and device.type == 'cuda')
        )
        optimizer.zero_grad()
        if residual_training:
            output = model(data, return_aux=True)
            loss, batch_stats = residual_training_loss(
                output, data.y.view(-1, 1).float(), lambda_sign,
                sign_threshold, temperature,
            )
        else:
            output = model(data)
            loss, batch_stats = regression_with_sign_loss(
                output, data.y.view(-1, 1).float(), lambda_sign,
                sign_threshold, temperature,
            )
        batch_size = data.y.numel()
        sample_count += batch_size
        for key, value in batch_stats.items():
            training_stats[key] = training_stats.get(key, 0.0) + (
                value.item() * batch_size
            )
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        grad_norms.append(grad_norm.detach())
        optimizer.step()
        if batch_idx % LOG_INTERVAL == 0:
            print('Train epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch,
                batch_idx * TRAIN_BATCH_SIZE,
                len(train_loader.dataset),
                100. * batch_idx / len(train_loader),
                loss.item()))

    grad_norms = torch.stack(grad_norms)
    result = {
        'mean_grad_norm': grad_norms.mean().item(),
        'max_grad_norm': grad_norms.max().item(),
        'fraction_grad_norm_gt_1': (grad_norms > 1.0).float().mean().item(),
    }
    result.update({key: value / sample_count
                   for key, value in training_stats.items()})
    return result


def predicting(model, device, loader):
    model.eval()
    total_preds = torch.Tensor()
    total_labels = torch.Tensor()
    all_compound_ids = []
    all_kinase_A_ids = []
    all_kinase_B_ids = []
    all_source_rows = []
    print('Make prediction for {} samples...'.format(len(loader.dataset)))
    with torch.no_grad():
        for data in loader:
            data = data.to(
                device, non_blocking=(PIN_MEMORY and device.type == 'cuda')
            )
            output = model(data)
            total_preds = torch.cat((total_preds, output.cpu()), 0)
            total_labels = torch.cat((total_labels, data.y.view(-1, 1).cpu()), 0)
            all_compound_ids.extend(data.compound_id if isinstance(data.compound_id, list)
                                    else data.compound_id.cpu().tolist())
            all_kinase_A_ids.extend(data.kinase_A_id)
            all_kinase_B_ids.extend(data.kinase_B_id)
            all_source_rows.extend(data.source_row.cpu().tolist())
    return (total_labels.numpy().flatten(),
            total_preds.numpy().flatten(),
            all_compound_ids,
            all_kinase_A_ids,
            all_kinase_B_ids,
            all_source_rows)


def prediction_metrics(labels, predictions):
    return {
        'rmse': rmse(labels, predictions),
        'mse': mse(labels, predictions),
        'mae': mae(labels, predictions),
        'pearson': pearson(labels, predictions),
        'spearman': spearman(labels, predictions),
        'direction_accuracy': direction_accuracy(labels, predictions),
        'direction_accuracy_ge_0_5': direction_accuracy(
            labels, predictions, min_abs_label=0.5
        ),
        'n_direction_samples': direction_sample_count(labels),
        'n_direction_samples_ge_0_5': direction_sample_count(
            labels, min_abs_label=0.5
        ),
    }


def set_seed(seed: int):
    """Seed all RNG sources for reproducibility within a rep."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def run_one_rep(rep_id: int, seed: int, modeling, device,
                train_data, val_data, test_data, model_st, esm_dim,
                esm_transform, model_kwargs, run_root, pretrained_v1=None,
                lambda_sign=0.1, sign_threshold=0.5, temperature=1.0):
    """Run one full training repetition and return its test metrics + preds."""
    print(f"\n{'=' * 70}")
    print(f"REP {rep_id}  (seed={seed})  model={model_st}")
    print(f"{'=' * 70}\n")

    set_seed(seed)

    # ---- Loaders (rebuild per rep so shuffle uses fresh RNG state) ----
    # Use a generator so train shuffling is reproducible given the seed.
    g = torch.Generator()
    g.manual_seed(seed)
    loader_options = {
        'esm_transform': esm_transform,
        'num_workers': NUM_WORKERS,
        'pin_memory': PIN_MEMORY and device.type == 'cuda',
    }
    train_loader = make_pair_data_loader(
        train_data, batch_size=TRAIN_BATCH_SIZE, shuffle=True, generator=g,
        **loader_options,
    )
    val_loader = make_pair_data_loader(
        val_data, batch_size=TEST_BATCH_SIZE, shuffle=False, **loader_options,
    )
    test_loader = make_pair_data_loader(
        test_data, batch_size=TEST_BATCH_SIZE, shuffle=False, **loader_options,
    )

    # ---- Fresh model per rep ----
    model = modeling(pool_method='esm', esm_dim=esm_dim,
                     dropout=MODEL_DROPOUT, **model_kwargs).to(device)
    residual_training = pretrained_v1 is not None
    if residual_training:
        pretrained_path = Path(
            pretrained_v1.format(rep=rep_id, model=model_st)
        )
        if not pretrained_path.is_file():
            raise FileNotFoundError(f'V1 checkpoint not found: {pretrained_path}')
        state_dict = torch.load(
            pretrained_path, map_location=device, weights_only=False
        )
        transferred = load_pretrained_v1(model, state_dict)
        freeze_pretrained_v1(model)
        print(f'Loaded frozen V1: {pretrained_path} ({len(transferred)} tensors)')

    trainable_parameters = [
        parameter for parameter in model.parameters() if parameter.requires_grad
    ]
    if not trainable_parameters:
        raise RuntimeError('Model has no trainable parameters')
    optimizer = torch.optim.Adam(trainable_parameters, lr=LR,
                                 weight_decay=WEIGHT_DECAY)
    print(f'Trainable parameters: {sum(p.numel() for p in trainable_parameters):,}')

    best_val_mse = float('inf')
    best_val_metrics = None
    best_epoch = -1
    patience_counter = 0
    epoch_history = []
    artifact_name = f'{model_st}_esm_rep{rep_id}'
    model_file_name = run_root / 'checkpoints' / f'model_{artifact_name}.model'
    print(f'Save to: {model_file_name}')
    validation_predictions_dir = None
    if SAVE_VALIDATION_PREDICTIONS:
        validation_predictions_dir = (
            run_root / 'validation_predictions' / artifact_name
        )
        validation_predictions_dir.mkdir(parents=True, exist_ok=False)
        print(f'Validation predictions: {validation_predictions_dir}')
    else:
        print('Validation predictions: disabled')

    # ---- Train ----
    for epoch in range(NUM_EPOCHS):
        grad_stats = train(
            model, device, train_loader, optimizer, epoch + 1,
            residual_training=residual_training,
            lambda_sign=lambda_sign,
            sign_threshold=sign_threshold,
            temperature=temperature,
        )

        G_val, P_val, val_ligand_keys, val_kinase_A_ids, val_kinase_B_ids, val_source_rows = \
            predicting(model, device, val_loader)
        val_metrics = prediction_metrics(G_val, P_val)

        if SAVE_VALIDATION_PREDICTIONS:
            validation_prediction_file = validation_predictions_dir / f'epoch_{epoch + 1:03d}.csv.gz'
            pd.DataFrame({
                'epoch': epoch + 1,
                'source_row': val_source_rows,
                'ligand_key': val_ligand_keys,
                'kinase_A': val_kinase_A_ids,
                'kinase_B': val_kinase_B_ids,
                'true_label': G_val,
                'pred_score': P_val,
            }).to_csv(validation_prediction_file, index=False, compression='gzip')

        print(f'[rep {rep_id}] Val epoch {epoch + 1}: '
              f'RMSE={val_metrics["rmse"]:.4f}, '
              f'MSE={val_metrics["mse"]:.4f}, '
              f'MAE={val_metrics["mae"]:.4f}, '
              f'Pearson={val_metrics["pearson"]:.4f}, '
              f'Spearman={val_metrics["spearman"]:.4f}, '
              f'Direction={val_metrics["direction_accuracy"]:.4f}, '
              f'Direction(|y|>=0.5)='
              f'{val_metrics["direction_accuracy_ge_0_5"]:.4f}')
        print(f'  pred_mean={P_val.mean():.4f}, '
              f'pred_std={P_val.std():.4f}, '
              f'pred_absmean={np.abs(P_val).mean():.4f}, '
              f'pred_min={P_val.min():.4f}, '
              f'pred_max={P_val.max():.4f}')
        print(f'  mean_grad_norm={grad_stats["mean_grad_norm"]:.6f}, '
              f'max_grad_norm={grad_stats["max_grad_norm"]:.6f}, '
              f'fraction_grad_norm_gt_1={grad_stats["fraction_grad_norm_gt_1"]:.4f}')
        epoch_history.append({
            'epoch': epoch + 1,
            **{f'val_{key}': value for key, value in val_metrics.items()},
            'pred_mean': P_val.mean(),
            'pred_std': P_val.std(),
            'pred_absmean': np.abs(P_val).mean(),
            'pred_min': P_val.min(),
            'pred_max': P_val.max(),
            **grad_stats,
        })

        if val_metrics['mse'] < best_val_mse:
            best_val_mse = val_metrics['mse']
            best_val_metrics = val_metrics.copy()
            best_epoch = epoch + 1
            patience_counter = 0
            torch.save(model.state_dict(), model_file_name)
            print(f'  ** [rep {rep_id}] Val MSE improved at epoch {best_epoch}: '
                  f'{best_val_mse:.4f}')
        else:
            patience_counter += 1
            print(f'  [rep {rep_id}] No improvement since epoch {best_epoch}, '
                  f'best val MSE: {best_val_mse:.4f}, '
                  f'patience: {patience_counter}/{PATIENCE}')
            if patience_counter >= PATIENCE:
                print(f'\n[rep {rep_id}] Early stopping at epoch {epoch + 1}')
                break

    history_file_name = run_root / 'histories' / f'history_{artifact_name}.csv'
    pd.DataFrame(epoch_history).to_csv(history_file_name, index=False)
    print(f'[rep {rep_id}] Epoch diagnostics saved to {history_file_name}')

    # ---- Final test with best checkpoint ----
    print(f'\n[rep {rep_id}] Loading best model from epoch {best_epoch}...')
    model.load_state_dict(torch.load(model_file_name, weights_only=False))
    G_test, P_test, compound_ids, kinase_A_ids, kinase_B_ids, source_rows = \
        predicting(model, device, test_loader)
    test_metrics = prediction_metrics(G_test, P_test)

    print(f'\n===== [rep {rep_id}] Test Results ({model_st} + esm) =====')
    print(f'RMSE:                    {test_metrics["rmse"]:.4f}')
    print(f'MSE:                     {test_metrics["mse"]:.4f}')
    print(f'MAE:                     {test_metrics["mae"]:.4f}')
    print(f'Pearson:                 {test_metrics["pearson"]:.4f}')
    print(f'Spearman:                {test_metrics["spearman"]:.4f}')
    print(f'Direction accuracy:      '
          f'{test_metrics["direction_accuracy"]:.4f}')
    print(f'Direction accuracy >=.5: '
          f'{test_metrics["direction_accuracy_ge_0_5"]:.4f}')
    print(f'Best epoch: {best_epoch}')

    # ---- Save per-rep predictions ----
    pred_file_name = run_root / 'test_predictions' / f'pred_{artifact_name}.csv'
    pred_df = pd.DataFrame({
        'ligand_key':  compound_ids,
        'kinase_A':    kinase_A_ids,
        'kinase_B':    kinase_B_ids,
        'source_row':  source_rows,
        'pred_score':  P_test,
        'true_label':  G_test,
    })
    pred_df.to_csv(pred_file_name, index=False)
    print(f'[rep {rep_id}] Predictions saved to {pred_file_name} '
          f'({len(pred_df)} samples)')

    return {
        'rep':       rep_id,
        'seed':      seed,
        'best_epoch': best_epoch,
        **{f'best_val_{key}': value
           for key, value in best_val_metrics.items()},
        **test_metrics,
        'pred_df':   pred_df,
    }


parser = argparse.ArgumentParser(description='Train the GAT-GCN paired-kinase model')
parser.add_argument('--cuda-id', type=int, default=0, help='CUDA device index')
parser.add_argument('--n-reps', type=int, default=1)
parser.add_argument('--esm-cache', default='data/wt_esm/esm2_t33_650M_UR50D_residue.pt')
parser.add_argument('--data-root', default='data/wt_esm')
parser.add_argument('--split', type=Path, default=Path('data/wt_esm/split.npz'))
parser.add_argument('--config', type=Path, default=DEFAULT_TRAINING_CONFIG,
                    help='JSON config; values below can override it')
parser.add_argument(
    '--seed', type=int,
    help='Explicit seed for a single-repetition run (requires n_reps=1)',
)
parser.add_argument(
    '--run-dir', type=Path,
    help='Exact output directory; must not already exist (default: runs/<timestamp>)',
)
parser.add_argument('--train-batch-size', type=int)
parser.add_argument('--eval-batch-size', type=int)
parser.add_argument('--lr', '--learning-rate', dest='learning_rate', type=float)
parser.add_argument('--weight-decay', type=float)
parser.add_argument('--epochs', '--num-epochs', dest='num_epochs', type=int)
parser.add_argument('--patience', type=int)
parser.add_argument('--log-interval', type=int)
parser.add_argument('--dropout', type=float)
parser.add_argument('--residue-dim', type=int)
parser.add_argument('--attn-hidden', type=int)
parser.add_argument('--local-hidden', type=int)
parser.add_argument(
    '--residue-top-k', type=int,
    help='archived shared-scorer option; must be 0 for the active residue branch',
)
parser.add_argument('--lambda-sign', type=float)
parser.add_argument('--sign-threshold', type=float)
parser.add_argument('--temperature', type=float)
parser.add_argument('--num-workers', type=int)
pin_memory_group = parser.add_mutually_exclusive_group()
pin_memory_group.add_argument(
    '--pin-memory', dest='pin_memory', action='store_true', default=None,
)
pin_memory_group.add_argument(
    '--no-pin-memory', dest='pin_memory', action='store_false',
)
parser.add_argument(
    '--pair-head',
    choices=('difference_v2', 'difference_v1'),
    default='difference_v2',
)
parser.add_argument(
    '--pretrained-v1',
    help=(
        'difference_v1 checkpoint used as the frozen baseline; required for '
        'difference_v2. The path may contain {model} and {rep} '
        'placeholders'
    ),
)
validation_prediction_group = parser.add_mutually_exclusive_group()
validation_prediction_group.add_argument(
    '--save-validation-predictions', dest='save_validation_predictions',
    action='store_true', default=None,
)
validation_prediction_group.add_argument(
    '--no-save-validation-predictions', dest='save_validation_predictions',
    action='store_false',
)
args = parser.parse_args()

CONFIG_PATH = args.config
cli_hyperparameter_overrides = {
    key: getattr(args, key)
    for key in (
        'train_batch_size', 'eval_batch_size', 'learning_rate',
        'weight_decay', 'num_epochs', 'patience', 'log_interval',
        'dropout', 'residue_dim', 'attn_hidden', 'local_hidden',
        'residue_top_k', 'lambda_sign', 'sign_threshold', 'temperature',
        'num_workers', 'pin_memory', 'save_validation_predictions',
    )
    if getattr(args, key) is not None
}
TRAINING_CONFIG = load_training_config(CONFIG_PATH, cli_hyperparameter_overrides)
TRAIN_BATCH_SIZE = TRAINING_CONFIG['train_batch_size']
TEST_BATCH_SIZE = TRAINING_CONFIG['eval_batch_size']
LR = float(TRAINING_CONFIG['learning_rate'])
WEIGHT_DECAY = float(TRAINING_CONFIG['weight_decay'])
LOG_INTERVAL = TRAINING_CONFIG['log_interval']
NUM_EPOCHS = TRAINING_CONFIG['num_epochs']
PATIENCE = TRAINING_CONFIG['patience']
MODEL_DROPOUT = float(TRAINING_CONFIG['dropout'])
RESIDUE_DIM = TRAINING_CONFIG['residue_dim']
ATTN_HIDDEN = TRAINING_CONFIG['attn_hidden']
LOCAL_HIDDEN = TRAINING_CONFIG['local_hidden']
RESIDUE_TOP_K = TRAINING_CONFIG['residue_top_k']
LAMBDA_SIGN = float(TRAINING_CONFIG['lambda_sign'])
SIGN_THRESHOLD = float(TRAINING_CONFIG['sign_threshold'])
TEMPERATURE = float(TRAINING_CONFIG['temperature'])
NUM_WORKERS = TRAINING_CONFIG['num_workers']
PIN_MEMORY = TRAINING_CONFIG['pin_memory']
SAVE_VALIDATION_PREDICTIONS = TRAINING_CONFIG['save_validation_predictions']

pair_head = args.pair_head
if pair_head == 'difference_v2' and args.pretrained_v1 is None:
    parser.error('--pretrained-v1 is required for difference_v2 residual training')
if pair_head != 'difference_v2' and args.pretrained_v1 is not None:
    parser.error('--pretrained-v1 can only be used with difference_v2')
modeling = GAT_GCN if pair_head == 'difference_v2' else DifferenceV1GAT_GCN
cuda_name = f'cuda:{args.cuda_id}'
N_REPS = args.n_reps
ESM_CACHE = args.esm_cache
DATA_ROOT = args.data_root
if N_REPS < 1:
    raise ValueError('n_reps must be positive')
if args.seed is not None and N_REPS != 1:
    parser.error('--seed requires n_reps=1')
if args.seed is not None and args.seed < 0:
    parser.error('--seed must be non-negative')

# Fixed seeds — chosen for consistency with your other multi-seed work
if args.seed is not None:
    SEEDS = [args.seed]
else:
    SEEDS = [42]
    if N_REPS > len(SEEDS):
        # Extend deterministically if more reps requested
        SEEDS = SEEDS + list(range(2025, 2025 + (N_REPS - len(SEEDS))))
    SEEDS = SEEDS[:N_REPS]

model_st = modeling.__name__
model_kwargs = {}
if pair_head == 'difference_v2':
    model_kwargs = {
        'residue_dim': RESIDUE_DIM,
        'attn_hidden': ATTN_HIDDEN,
        'local_hidden': LOCAL_HIDDEN,
        'residue_top_k': RESIDUE_TOP_K,
    }
print(f'Model: {model_st}, Pair head: {pair_head}, '
      f'Device: {cuda_name}')
print(f'N_REPS: {N_REPS}, Seeds: {SEEDS}')
print(f'Training config: {CONFIG_PATH}')
print(f'Learning rate: {LR}, Weight decay: {WEIGHT_DECAY}, '
      f'Dropout: {MODEL_DROPOUT}, Epochs: {NUM_EPOCHS}, Patience: {PATIENCE}')
print(f'Train/eval batch size: {TRAIN_BATCH_SIZE}/{TEST_BATCH_SIZE}, '
      f'workers: {NUM_WORKERS}, pin memory: {PIN_MEMORY}, '
      f'Save validation predictions: {SAVE_VALIDATION_PREDICTIONS}')
if model_kwargs:
    print(f'Residue branch: {model_kwargs}')
    print('Residual formulation: frozen V1 + delta_local')
    print(f'V1 checkpoint pattern: {args.pretrained_v1}')
print(f'Loss: MSE + {LAMBDA_SIGN:g} * sign BCE '
      f'(threshold={SIGN_THRESHOLD:g}, temperature={TEMPERATURE:g})')

print('\nLoading full dataset...')
esm_transform = ESMEmbeddingTransform(
    ESM_CACHE, require_residue=(pair_head == 'difference_v2')
)
full_data = SiameseTestbedDataset(root=DATA_ROOT, dataset='selectivity_all_wt', transform=esm_transform)
device = torch.device(cuda_name if torch.cuda.is_available() else 'cpu')
parts = load_split(full_data, args.split)
train_data = Subset(full_data, parts['train'].tolist())
val_data = Subset(full_data, parts['val'].tolist())
test_data = Subset(full_data, parts['test'].tolist())
print(f'Split: train {len(train_data)}, val {len(val_data)}, test {len(test_data)}')

run_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
run_root = args.run_dir if args.run_dir is not None else Path('runs') / run_timestamp
if run_root.exists():
    raise FileExistsError(f'Run output directory already exists: {run_root}')
artifact_dirs = ['checkpoints', 'test_predictions', 'histories', 'results']
if SAVE_VALIDATION_PREDICTIONS:
    artifact_dirs.append('validation_predictions')
for artifact_dir in artifact_dirs:
    (run_root / artifact_dir).mkdir(parents=True, exist_ok=False)
print(f'Run output root: {run_root}')
(run_root / 'run_config.json').write_text(json.dumps({
    'model': model_st,
    'prediction_head': pair_head,
    'pool_method': 'esm',
    'device': cuda_name,
    'n_reps': N_REPS,
    'seeds': SEEDS,
    'esm_cache': ESM_CACHE,
    'data_root': DATA_ROOT,
    'split': str(args.split),
    'pretrained_v1': args.pretrained_v1,
    'local_scale': 1.0 if pair_head == 'difference_v2' else None,
    'training_config_path': str(CONFIG_PATH),
    'run_dir': str(run_root),
    'cli_hyperparameter_overrides': cli_hyperparameter_overrides,
    'hyperparameters': TRAINING_CONFIG,
}, indent=2) + '\n')

all_results = []
for rep_id, seed in enumerate(SEEDS):
    all_results.append(run_one_rep(
        rep_id=rep_id, seed=seed, modeling=modeling,
        device=device, train_data=train_data, val_data=val_data, test_data=test_data,
        model_st=model_st, esm_dim=esm_transform.dim,
        esm_transform=esm_transform, model_kwargs=model_kwargs,
        run_root=run_root, pretrained_v1=args.pretrained_v1,
        lambda_sign=LAMBDA_SIGN,
        sign_threshold=SIGN_THRESHOLD,
        temperature=TEMPERATURE,
    ))

per_rep_df = pd.DataFrame([{k: v for k, v in result.items() if k != 'pred_df'}
                           for result in all_results])
print(f'\nTest metrics:\n{per_rep_df.to_string(index=False)}')
per_rep_df.to_csv(
    run_root / 'results' / f'result_{model_st}_esm_allreps.csv', index=False,
)

ensemble = all_results[0]['pred_df'].rename(columns={'pred_score': 'pred_rep0'}).copy()
for rep_id, result in enumerate(all_results[1:], start=1):
    if not ensemble['source_row'].equals(result['pred_df']['source_row']):
        raise ValueError('Prediction orders differ between repetitions')
    ensemble[f'pred_rep{rep_id}'] = result['pred_df']['pred_score'].values
pred_cols = [f'pred_rep{i}' for i in range(N_REPS)]
ensemble['pred_mean'] = ensemble[pred_cols].mean(axis=1)
ensemble['pred_std'] = ensemble[pred_cols].std(axis=1, ddof=0)
ensemble.to_csv(
    run_root / 'test_predictions' / f'pred_{model_st}_esm_ensemble.csv',
    index=False,
)
